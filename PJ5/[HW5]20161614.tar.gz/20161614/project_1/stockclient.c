/*
 * echoclient.c - An echo client
 */
/* $begin echoclientmain */
#include "csapp.h"

int showFlag=0;

void PrintContents(char* buf){
	//printf("buf : %s\n",buf);
	FILE* fp;
	fp=fopen("temp.txt","w");
	fwrite(buf,strlen(buf),1,fp);
	fclose(fp);
	FILE* fp2;
	fp2=fopen("temp.txt","r");

	int id,quantity,price;
	while(!feof(fp2)){
		fscanf(fp2,"%d %d %d ",&id,&quantity,&price);
		printf("%d %d %d\n",id,quantity,price);
	}
}


int main(int argc, char **argv) 
{
	int clientfd;
	char *host, *port, buf[MAXLINE];
	rio_t rio;

	if (argc != 3) {
		fprintf(stderr, "usage: %s <host> <port>\n", argv[0]);
		exit(0);
	}
	host = argv[1];
	port = argv[2];

	clientfd = Open_clientfd(host, port);
	Rio_readinitb(&rio, clientfd);


	while (Fgets(buf, MAXLINE, stdin) != NULL) {
		if(!strcmp(buf,"exit\n"))
			exit(0);
		if(!strcmp(buf,"show\n"))
			showFlag=1;
		Rio_writen(clientfd, buf, strlen(buf));
		Rio_readlineb(&rio, buf, MAXLINE);
		//printf("Buf successfully read\n");
		//printf("received buf : %s\n",buf);
		if(showFlag==1){
			// process string and show
			PrintContents(buf);
			showFlag=0;
		}
		else
			Fputs(buf, stdout);
	}
	//showFlag=1;
	Close(clientfd); //line:netp:echoclient:close
	exit(0);
}
/* $end echoclientmain */
