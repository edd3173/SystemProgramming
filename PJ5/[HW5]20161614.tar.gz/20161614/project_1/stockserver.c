/* 
 * echoservers.c - A concurrent echo server based on select
 */
/* $begin echoserversmain */
#include "csapp.h"
#include <string.h>
#include <time.h>

typedef struct _StockNode {
	int id;
	int quantity;
	int price;
}StockNode;

StockNode StockData[1024];

int StockDataCount=0;

typedef struct _treeNode {
	struct _treeNode* leftChild;
	struct _treeNode* rightChild;
	StockNode data;
}treeNode;

treeNode* ROOT;

char RESPONSE[1024];
char tempResponse[128];
float timeTotal=0;

treeNode* SearchNode(treeNode* Tree, int targetID);
treeNode* SearchMinNode(treeNode* Tree);
void InsertNode(treeNode* Tree, treeNode* target);
treeNode* RemoveNode(treeNode* Tree, treeNode* Parent, int targetID);
treeNode* createNode(StockNode newStockNode);
void Inorder(treeNode* Node);
void ConstructBinaryTree();
void writeStockData(treeNode* Node);

char* ShowStocks();
char* Buy(int targetID, int targetQuantity);
char* Sell(int targetID, int targetQuantity);
void Exit();
char* Evaluate(char* cmd);
//void Push(StackNode** topRef, treeNode* t);
//treeNode* Pop(StackNode** topRef);
//int isEmpty(StackNode* top);
//void IterInorder(treeNode* root);


typedef struct { /* Represents a pool of connected descriptors */ //line:conc:echoservers:beginpool
	int maxfd;        /* Largest descriptor in read_set */   
	fd_set read_set;  /* Set of all active descriptors */
	fd_set ready_set; /* Subset of descriptors ready for reading  */
	int nready;       /* Number of ready descriptors from select */   
	int maxi;         /* Highwater index into client array */
	int clientfd[FD_SETSIZE];    /* Set of active descriptors */
	rio_t clientrio[FD_SETSIZE]; /* Set of active read buffers */
} pool; //line:conc:echoservers:endpool
/* $end echoserversmain */
void init_pool(int listenfd, pool *p);
void add_client(int connfd, pool *p);
void check_clients(pool *p);
/* $begin echoserversmain */

int byte_cnt = 0; /* Counts total bytes received by server */


int main(int argc, char **argv)
{

	// do some file preprocessing

	FILE* sFP = fopen("stock.txt", "r");
	while (!feof(sFP)) {
		StockNode temp;
		int tempID, tempQuantity, tempPrice;
		fscanf(sFP, "%d %d %d", &tempID, &tempQuantity, &tempPrice);
		temp.id = tempID; temp.quantity = tempQuantity; temp.price = tempPrice;
		StockData[StockDataCount++] = temp;
	}
	ConstructBinaryTree();





	int listenfd, connfd;
	socklen_t clientlen;
	struct sockaddr_storage clientaddr;
	static pool pool; 

	if (argc != 2) {
		fprintf(stderr, "usage: %s <port>\n", argv[0]);
		exit(0);
	}
	listenfd = Open_listenfd(argv[1]);
	init_pool(listenfd, &pool); //line:conc:echoservers:initpool



	while (1) {
		/* Wait for listening/connected descriptor(s) to become ready */
		pool.ready_set = pool.read_set;
		pool.nready = Select(pool.maxfd+1, &pool.ready_set, NULL, NULL, NULL);

		/* If listening descriptor ready, add new client to pool */
		if (FD_ISSET(listenfd, &pool.ready_set)) { //line:conc:echoservers:listenfdready
			clientlen = sizeof(struct sockaddr_storage);
			connfd = Accept(listenfd, (SA *)&clientaddr, &clientlen); //line:conc:echoservers:accept
			add_client(connfd, &pool); //line:conc:echoservers:addclient
		}

		/* Echo a text line from each ready connected descriptor */ 
		check_clients(&pool); //line:conc:echoservers:checkclients
	}
}
/* $end echoserversmain */

/* $begin init_pool */
void init_pool(int listenfd, pool *p) 
{
	/* Initially, there are no connected descriptors */
	int i;
	p->maxi = -1;                   //line:conc:echoservers:beginempty
	for (i=0; i< FD_SETSIZE; i++)  
		p->clientfd[i] = -1;        //line:conc:echoservers:endempty

	/* Initially, listenfd is only member of select read set */
	p->maxfd = listenfd;            //line:conc:echoservers:begininit
	FD_ZERO(&p->read_set);
	FD_SET(listenfd, &p->read_set); //line:conc:echoservers:endinit
}
/* $end init_pool */

/* $begin add_client */
void add_client(int connfd, pool *p) 
{
	int i;
	p->nready--;
	for (i = 0; i < FD_SETSIZE; i++)  /* Find an available slot */
		if (p->clientfd[i] < 0) { 
			/* Add connected descriptor to the pool */
			p->clientfd[i] = connfd;                 //line:conc:echoservers:beginaddclient
			Rio_readinitb(&p->clientrio[i], connfd); //line:conc:echoservers:endaddclient

			/* Add the descriptor to descriptor set */
			FD_SET(connfd, &p->read_set); //line:conc:echoservers:addconnfd

			/* Update max descriptor and pool highwater mark */
			if (connfd > p->maxfd) //line:conc:echoservers:beginmaxfd
				p->maxfd = connfd; //line:conc:echoservers:endmaxfd
			if (i > p->maxi)       //line:conc:echoservers:beginmaxi
				p->maxi = i;       //line:conc:echoservers:endmaxi
			break;
		}
	if (i == FD_SETSIZE) /* Couldn't find an empty slot */
		app_error("add_client error: Too many clients");
}
/* $end add_client */

/* $begin check_clients */
void check_clients(pool *p) 
{
	int i, connfd, n;
	char buf[MAXLINE]; 
	char* reply;
	rio_t rio;


	for (i = 0; (i <= p->maxi) && (p->nready > 0); i++) {
		
		connfd = p->clientfd[i];
		rio = p->clientrio[i];

		/* If the descriptor is ready, echo a text line from it */

		// guess we should do things with buffer here.
		if ((connfd > 0) && (FD_ISSET(connfd, &p->ready_set))) { 
			p->nready--;
			if ((n = Rio_readlineb(&rio, buf, MAXLINE)) != 0) {
				

				byte_cnt += n; //line:conc:echoservers:beginecho
				printf("***** New Iteration *****\n");
				printf("Server received %d (%d total) bytes on fd %d\n", 
						n, byte_cnt, connfd);
				printf("Contents of Buf : |%s|",buf);

				//Evaluate(buf);
				reply=(char*)malloc(sizeof(char)*MAXLINE);
				memset(reply,0,strlen(reply));
				printf("Evaluation Done\n");
				//printf("Writing Reply...\n");
				reply=Evaluate(buf);
				
				printf("Updating data of stock.txt...\n");
				writeStockData(ROOT);
				
				// case of show, put delim
				if(!strcmp(buf,"show\n"))
					strcat(reply,"\n");


				printf("\n===== Sending Reply =====\n");
				printf("|%s|",reply);
				Rio_writen(connfd, reply, strlen(reply));
				printf("Reply sent\n");

			}

			/* EOF detected, remove descriptor from pool */
			else { 
				Close(connfd); //line:conc:echoservers:closeconnfd
				FD_CLR(connfd, &p->read_set); //line:conc:echoservers:beginremove
				p->clientfd[i] = -1;    //line:conc:echoservers:endremove
				//printf("Updating data of stock.txt...");
				//writeStockData(ROOT);
			}
		}

	}
}
/* $end check_clients */


treeNode* SearchNode(treeNode* Tree, int targetID) {
	if (Tree == NULL)
		return NULL;

	if (Tree->data.id == targetID)
		return Tree;
	else if (Tree->data.id > targetID)
		return SearchNode(Tree->leftChild, targetID);
	else
		return SearchNode(Tree->rightChild, targetID);
}

treeNode* SearchMinNode(treeNode* Tree) {
	if (Tree == NULL)
		return NULL;

	if (Tree->leftChild == NULL)
		return Tree;
	else
		return SearchMinNode(Tree->leftChild);
}

void InsertNode(treeNode* Tree, treeNode* target) {
	if (Tree->data.id < target->data.id) {
		if (Tree->rightChild == NULL)
			Tree->rightChild = target;
		else
			InsertNode(Tree->rightChild, target);
	}
	else if (Tree->data.id > target->data.id) {
		if (Tree->leftChild == NULL)
			Tree->leftChild = target;
		else
			InsertNode(Tree->leftChild, target);
	}
}



treeNode* RemoveNode(treeNode* Tree, treeNode* Parent, int targetID) {
	treeNode* Removed = NULL;
	if (Tree == NULL)
		return NULL;

	if (Tree->data.id > targetID)
		Removed = RemoveNode(Tree->leftChild, Tree, targetID);
	else if (Tree->data.id < targetID)
		Removed = RemoveNode(Tree->rightChild, Tree, targetID);
	else {
		Removed = Tree;

		if (Tree->leftChild == NULL && Tree->rightChild == NULL) {
			if (Parent->leftChild == Tree)
				Parent->leftChild = NULL;
			else
				Parent->rightChild = NULL;
		}
		else {
			if (Tree->leftChild != NULL && Tree->rightChild != NULL) {
				treeNode* minNode = SearchMinNode(Tree->rightChild);
				minNode = RemoveNode(Tree, NULL, minNode->data.id);
				Tree->data = minNode->data;
			}
			else {
				treeNode* temp = NULL;
				if (Tree->leftChild != NULL)
					temp = Tree->leftChild;
				else
					temp = Tree->rightChild;

				if (Parent->leftChild == Tree)
					Parent->leftChild = temp;
				else
					Parent->rightChild = temp;
			}
		}
	}
	return Removed;
}

treeNode* createNode(StockNode newStockNode) {
	treeNode* newNode = (treeNode*)malloc(sizeof(treeNode));
	newNode->leftChild = NULL;
	newNode->rightChild = NULL;
	newNode->data = newStockNode;

	return newNode;
}

/*
   treeNode* createNode(int targetID) {
   treeNode* newNode = (treeNode*)malloc(sizeof(treeNode));
   newNode->leftChild = NULL;
   newNode->rightChild = NULL;
   newNode->data.id = targetID;

   return newNode;
   }
 */


void Inorder(treeNode* Node) {
	memset(tempResponse,0,sizeof(tempResponse));
	if (Node == NULL)
		return;
	Inorder(Node->leftChild);
	printf("\n(I:%d,Q:%d,P:%d)\n", Node->data.id,Node->data.quantity,Node->data.price);
	sprintf(tempResponse,"%d %d %d ", Node->data.id,Node->data.quantity,Node->data.price);
	strcat(RESPONSE,tempResponse);
	Inorder(Node->rightChild);
}



void ConstructBinaryTree() {
	// With StockDatas, we contruct binary tree
	/*
	   StockNode temp;
	   temp.id = 123;
	   ROOT = createNode(temp);
	   InsertNode(ROOT, createNode(22));
	   InsertNode(ROOT, createNode(9918));
	   InsertNode(ROOT, createNode(424));
	   InsertNode(ROOT, createNode(17));
	   InsertNode(ROOT, createNode(3));

	   InsertNode(ROOT, createNode(98));
	   InsertNode(ROOT, createNode(34));

	   InsertNode(ROOT, createNode(760));
	   InsertNode(ROOT, createNode(317));
	   InsertNode(ROOT, createNode(1));

	   Inorder(ROOT);

	   cout << "\nRemoving 98..." << endl;

	   treeNode* Node = RemoveNode(ROOT, NULL, 98);

	   Inorder(ROOT);

	   cout << "\nInserting 111..." << endl;
	   InsertNode(ROOT, createNode(111));
	   Inorder(ROOT);
	 */

	StockNode root = StockData[0];
	ROOT = createNode(root);

	for (int i = 1; i < StockDataCount; i++) {
		treeNode* temp = createNode(StockData[i]);
		InsertNode(ROOT, temp);
		//free(temp);
	}
	printf("===== Inital Data =====\n");
	Inorder(ROOT);
	//IterInorder(ROOT);
}

void writeStockData(treeNode* Node) {
	//TODO : write data in stock.txt
	memset(RESPONSE, 0, sizeof(RESPONSE));
	Inorder(ROOT);
	FILE* fp;
	fp=fopen("temp.txt","w");
	fwrite(RESPONSE,strlen(RESPONSE),1,fp);
	fclose(fp);
	FILE* fp2;
	fp2=fopen("temp.txt","r");
	FILE* fp3;
	fp3=fopen("stock.txt","w");

	int id,quantity, price;
	while(!feof(fp2)){
		fscanf(fp2,"%d %d %d ",&id,&quantity,&price);
		fprintf(fp3, "%d %d %d\n",id,quantity,price);
	}
	fclose(fp2);
	fclose(fp3);
}


char* Buy(int targetID, int targetQuantity) {
	treeNode* curr = SearchNode(ROOT, targetID);
	printf("BuyingNode : (%d, %d, %d)\n", curr->data.id, curr->data.quantity, curr->data.price);
	char* result;
	// let's see if change happened.
	if (curr->data.quantity >= targetQuantity) {
		curr->data.quantity -= targetQuantity;

		result="[buy] success\n";
	}
	else {
		// need to discard
		result="Not Enough Stock Left!\n";
	}
	
	printf("\nAfter buying...\n");
	Inorder(ROOT);

	// 필요없는듯? Hurray!
	// 이거 결국 parent를 가져와야하는거 아냐??
	//RemoveNode(ROOT, NULL, targetID);
	//InsertNode(ROOT, curr);
	return result;
}

char* Sell(int targetID, int targetQuantity) {
	treeNode* curr = SearchNode(ROOT, targetID);
	printf("SellingNode : (%d, %d, %d)\n", curr->data.id, curr->data.quantity, curr->data.price);
	char* result;
	// let's see if change happened in the server.
	curr->data.quantity += targetQuantity;
	result="[sell] success\n";

	printf("\nAfter Selling...\n");
	Inorder(ROOT);

	return result;
}

char* ShowStocks(){
	printf("I'm at showing\n");
	memset(RESPONSE,0,sizeof(RESPONSE));
	Inorder(ROOT);
	// TODO : need to make buf, save data of tree
	printf("\n=== Printing Response ===\n");
	printf("|%s|",RESPONSE);
	printf("\n=== Done Printing Response ===\n");
	return RESPONSE;
}

char* Evaluate(char* buf){
	//printf("I'm at Evaluation!\n");
	//printf("Buffer is : |%s|",buf);
	// TODO: Parse buf into three chunk.
	char* buf_copy = (char*)malloc(sizeof(char) * 16);
	strcpy(buf_copy, buf);
	//printf("buf_copy is : |%s|\n",buf_copy);
	char* sArr[3] = { NULL, };    // 크기가 10인 문자열 포인터 배열을 선언하고 NULL로 초기화
	int i = 0;                     // 문자열 포인터 배열의 인덱스로 사용할 변수
	char* ptr = strtok(buf_copy, " ");   // 공백 문자열을 기준으로 문자열을 자름
	while (ptr != NULL)            // 자른 문자열이 나오지 않을 때까지 반복
	{
		sArr[i] = ptr;             // 문자열을 자른 뒤 메모리 주소를 문자열 포인터 배열에 저장
		i++;                       // 인덱스 증가
		ptr = strtok(NULL, " ");   // 다음 문자열을 잘라서 포인터를 반환
	}

	char* RESULT=(char*)malloc(sizeof(char)*128);
	if (!strcmp(sArr[0], "buy")) {
		printf("Do Buy!\n");
		int id = atoi(sArr[1]);
		int quantity = atoi(sArr[2]);
		printf("id : %d, quantity : %d\n", id, quantity);
		RESULT=Buy(id,quantity);
	}
	else if (!strcmp(sArr[0], "sell")) {
		printf("Do sell!\n");
		int id = atoi(sArr[1]);
		int quantity = atoi(sArr[2]);
		printf("id : %d, quantity : %d\n", id, quantity);
		RESULT=Sell(id,quantity);
	}
	else if (!strcmp(sArr[0], "show\n")) {
		RESULT=ShowStocks();
	}
	else{
		RESULT="WRONG INPUT FROM CLIENT!\n";
	}
	return RESULT;
}
