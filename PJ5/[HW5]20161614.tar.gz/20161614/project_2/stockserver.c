/* 
 * echoservert_pre.c - A prethreaded concurrent echo server
 */
/* $begin echoservertpremain */
#include "csapp.h"
#include "sbuf.h"
#include <string.h>
#include <time.h>

#define NTHREADS  128
#define SBUFSIZE  16


static int byte_cnt;  /* Byte counter */
static sem_t mutex;   /* and the mutex that protects it */


// DATA STRUCTURES //

typedef struct _StockNode {
	int id;
	int quantity;
	int price;
}StockNode;

StockNode StockData[1024];

int StockDataCount=0;

typedef struct _treeNode {
	struct _treeNode* leftChild;
	struct _treeNode* rightChild;
	StockNode data;
}treeNode;

treeNode* ROOT;

typedef struct _StackNode{
	struct _treeNode* data;
	struct _StackNode* next;
}StackNode;

char RESPONSE[1024];
char tempResponse[128];

treeNode* SearchNode(treeNode* Tree, int targetID);
treeNode* SearchMinNode(treeNode* Tree);
void InsertNode(treeNode* Tree, treeNode* target);
treeNode* RemoveNode(treeNode* Tree, treeNode* Parent, int targetID);
treeNode* createNode(StockNode newStockNode);
void Inorder(treeNode* Node);
void ConstructBinaryTree();
void writeStockData(treeNode* Node);

char* ShowStocks();
char* Buy(int targetID, int targetQuantity);
char* Sell(int targetID, int targetQuantity);
void Exit();
char* Evaluate(char* cmd);







void echo_cnt(int connfd);
void *thread(void *vargp);

sbuf_t sbuf; /* Shared buffer of connected descriptors */

int main(int argc, char **argv) 
{

	// DO some preprocessing with stock.txt

	FILE* sFP = fopen("stock.txt", "r");
	while (!feof(sFP)) {
		StockNode temp;
		int tempID, tempQuantity, tempPrice;
		fscanf(sFP, "%d %d %d", &tempID, &tempQuantity, &tempPrice);
		temp.id = tempID; temp.quantity = tempQuantity; temp.price = tempPrice;
		StockData[StockDataCount++] = temp;
	}
	ConstructBinaryTree();


	int i, listenfd, connfd;
	socklen_t clientlen;
	struct sockaddr_storage clientaddr;
	pthread_t tid; 

	if (argc != 2) {
		fprintf(stderr, "usage: %s <port>\n", argv[0]);
		exit(0);
	}
	listenfd = Open_listenfd(argv[1]);

	sbuf_init(&sbuf, SBUFSIZE); //line:conc:pre:initsbuf
	for (i = 0; i < NTHREADS; i++)  /* Create worker threads */ //line:conc:pre:begincreate
		Pthread_create(&tid, NULL, thread, NULL);               //line:conc:pre:endcreate

	while (1) { 
		clientlen = sizeof(struct sockaddr_storage);
		connfd = Accept(listenfd, (SA *) &clientaddr, &clientlen);
		sbuf_insert(&sbuf, connfd); /* Insert connfd in buffer */
	}


}

void *thread(void *vargp) 
{

	Pthread_detach(pthread_self()); 
	while (1) { 
		int connfd = sbuf_remove(&sbuf); /* Remove connfd from buffer */ //line:conc:pre:removeconnfd
		
		echo_cnt(connfd);                /* Service client */

		Close(connfd);
	}

}
treeNode* SearchNode(treeNode* Tree, int targetID) {
	if (Tree == NULL)
		return NULL;

	if (Tree->data.id == targetID)
		return Tree;
	else if (Tree->data.id > targetID)
		return SearchNode(Tree->leftChild, targetID);
	else
		return SearchNode(Tree->rightChild, targetID);
}

treeNode* SearchMinNode(treeNode* Tree) {
	if (Tree == NULL)
		return NULL;

	if (Tree->leftChild == NULL)
		return Tree;
	else
		return SearchMinNode(Tree->leftChild);
}

void InsertNode(treeNode* Tree, treeNode* target) {
	if (Tree->data.id < target->data.id) {
		if (Tree->rightChild == NULL)
			Tree->rightChild = target;
		else
			InsertNode(Tree->rightChild, target);
	}
	else if (Tree->data.id > target->data.id) {
		if (Tree->leftChild == NULL)
			Tree->leftChild = target;
		else
			InsertNode(Tree->leftChild, target);
	}
}



treeNode* RemoveNode(treeNode* Tree, treeNode* Parent, int targetID) {
	treeNode* Removed = NULL;
	if (Tree == NULL)
		return NULL;

	if (Tree->data.id > targetID)
		Removed = RemoveNode(Tree->leftChild, Tree, targetID);
	else if (Tree->data.id < targetID)
		Removed = RemoveNode(Tree->rightChild, Tree, targetID);
	else {
		Removed = Tree;

		if (Tree->leftChild == NULL && Tree->rightChild == NULL) {
			if (Parent->leftChild == Tree)
				Parent->leftChild = NULL;
			else
				Parent->rightChild = NULL;
		}
		else {
			if (Tree->leftChild != NULL && Tree->rightChild != NULL) {
				treeNode* minNode = SearchMinNode(Tree->rightChild);
				minNode = RemoveNode(Tree, NULL, minNode->data.id);
				Tree->data = minNode->data;
			}
			else {
				treeNode* temp = NULL;
				if (Tree->leftChild != NULL)
					temp = Tree->leftChild;
				else
					temp = Tree->rightChild;

				if (Parent->leftChild == Tree)
					Parent->leftChild = temp;
				else
					Parent->rightChild = temp;
			}
		}
	}
	return Removed;
}

treeNode* createNode(StockNode newStockNode) {
	treeNode* newNode = (treeNode*)malloc(sizeof(treeNode));
	newNode->leftChild = NULL;
	newNode->rightChild = NULL;
	newNode->data = newStockNode;

	return newNode;
}


void Inorder(treeNode* Node) {
	memset(tempResponse,0,sizeof(tempResponse));
	if (Node == NULL)
		return;
	Inorder(Node->leftChild);
	printf("\n(I:%d,Q:%d,P:%d)\n", Node->data.id,Node->data.quantity,Node->data.price);
	sprintf(tempResponse,"%d %d %d ", Node->data.id,Node->data.quantity,Node->data.price);
	strcat(RESPONSE,tempResponse);
	Inorder(Node->rightChild);
}



void ConstructBinaryTree() {

	StockNode root = StockData[0];
	ROOT = createNode(root);

	for (int i = 1; i < StockDataCount; i++) {
		treeNode* temp = createNode(StockData[i]);
		InsertNode(ROOT, temp);
		//free(temp);
	}
	printf("===== Inital Data =====\n");
	Inorder(ROOT);
	//IterInorder(ROOT);
}

void writeStockData(treeNode* Node) {
	//TODO : write data in stock.txt
	memset(RESPONSE, 0, sizeof(RESPONSE));
	Inorder(ROOT);
	FILE* fp;
	fp=fopen("temp.txt","w");
	fwrite(RESPONSE,strlen(RESPONSE),1,fp);
	fclose(fp);
	FILE* fp2;
	fp2=fopen("temp.txt","r");
	FILE* fp3;
	fp3=fopen("stock.txt","w");

	int id,quantity, price;
	while(!feof(fp2)){
		fscanf(fp2,"%d %d %d ",&id,&quantity,&price);
		fprintf(fp3, "%d %d %d\n",id,quantity,price);
	}
	fclose(fp2);
	fclose(fp3);
}


char* Buy(int targetID, int targetQuantity) {
	treeNode* curr = SearchNode(ROOT, targetID);
	printf("BuyingNode : (%d, %d, %d)\n", curr->data.id, curr->data.quantity, curr->data.price);
	char* result;
	// let's see if change happened.
	if (curr->data.quantity >= targetQuantity) {
		curr->data.quantity -= targetQuantity;

		result="[buy] success\n";
	}
	else {
		// need to discard
		result="Not Enough Stock Left!\n";
	}

	printf("\nAfter buying...\n");
	Inorder(ROOT);

	// 필요없는듯? Hurray!
	// 이거 결국 parent를 가져와야하는거 아냐??
	//RemoveNode(ROOT, NULL, targetID);
	//InsertNode(ROOT, curr);
	return result;
}

char* Sell(int targetID, int targetQuantity) {
	treeNode* curr = SearchNode(ROOT, targetID);
	printf("SellingNode : (%d, %d, %d)\n", curr->data.id, curr->data.quantity, curr->data.price);
	char* result;
	// let's see if change happened in the server.
	curr->data.quantity += targetQuantity;
	result="[sell] success\n";

	printf("\nAfter Selling...\n");
	Inorder(ROOT);

	return result;
}

char* ShowStocks(){
	printf("I'm at showing\n");
	memset(RESPONSE,0,sizeof(RESPONSE));
	Inorder(ROOT);
	// TODO : need to make buf, save data of tree
	printf("\n=== Printing Response ===\n");
	printf("|%s|",RESPONSE);
	printf("\n=== Done Printing Response ===\n");
	return RESPONSE;
}

char* Evaluate(char* buf){
	//printf("I'm at Evaluation!\n");
	//printf("Buffer is : |%s|",buf);
	// TODO: Parse buf into three chunk.
	char* buf_copy = (char*)malloc(sizeof(char) * 16);
	strcpy(buf_copy, buf);
	//printf("buf_copy is : |%s|\n",buf_copy);
	char* sArr[3] = { NULL, };    // 크기가 10인 문자열 포인터 배열을 선언하고 NULL로 초기화
	int i = 0;                     // 문자열 포인터 배열의 인덱스로 사용할 변수
	char* ptr = strtok(buf_copy, " ");   // 공백 문자열을 기준으로 문자열을 자름
	while (ptr != NULL)            // 자른 문자열이 나오지 않을 때까지 반복
	{
		sArr[i] = ptr;             // 문자열을 자른 뒤 메모리 주소를 문자열 포인터 배열에 저장
		i++;                       // 인덱스 증가
		ptr = strtok(NULL, " ");   // 다음 문자열을 잘라서 포인터를 반환
	}

	char* RESULT=(char*)malloc(sizeof(char)*128);
	if (!strcmp(sArr[0], "buy")) {
		printf("Do Buy!\n");
		int id = atoi(sArr[1]);
		int quantity = atoi(sArr[2]);
		printf("id : %d, quantity : %d\n", id, quantity);
		RESULT=Buy(id,quantity);
	}
	else if (!strcmp(sArr[0], "sell")) {
		printf("Do sell!\n");
		int id = atoi(sArr[1]);
		int quantity = atoi(sArr[2]);
		printf("id : %d, quantity : %d\n", id, quantity);
		RESULT=Sell(id,quantity);
	}
	else if (!strcmp(sArr[0], "show\n")) {
		RESULT=ShowStocks();
	}
	return RESULT;
}





static void init_echo_cnt(void)
{
	Sem_init(&mutex, 0, 1);
	byte_cnt = 0;
}

void echo_cnt(int connfd) 
{


	int n; 
	char buf[MAXLINE]; 
	rio_t rio;
	static pthread_once_t once = PTHREAD_ONCE_INIT;
	char* reply;
	Pthread_once(&once, init_echo_cnt); //line:conc:pre:pthreadonce
	Rio_readinitb(&rio, connfd);        //line:conc:pre:rioinitb
	while((n = Rio_readlineb(&rio, buf, MAXLINE)) != 0) {
		
		
		P(&mutex);
		byte_cnt += n; //line:conc:pre:cntaccess1
		printf("\n\n\n***** New Iteration *****\n");
		printf("server received %d (%d total) bytes on fd %d\n", 
				n, byte_cnt, connfd); //line:conc:pre:cntaccess2
		printf("Contents of Buf : |%s|\n",buf);

		reply=(char*)malloc(sizeof(char)*MAXLINE);
		memset(reply, 0, strlen(reply));
		reply=Evaluate(buf);
		printf("Evaluation done\n");

		printf("\n===== Updating Data Structure =====\n");
		writeStockData(ROOT);

		if(!strcmp(buf,"show\n"))
			strcat(reply,"\n");

		printf("\n===== Sending Reply =====\n");
		printf("|%s|\n",reply);


		V(&mutex);


		Rio_writen(connfd, reply, strlen(reply));
		printf("===== Reply Sent =====\n");
		
	}
}

/* $end echoservertpremain */
