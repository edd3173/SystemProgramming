/* $begin shellmain */
#include "csapp.h"
#define MAXARGS   128

#define READ_END 0
#define WRITE_END 1

/* Function prototypes */
void eval(char* cmdline);
int parseline(char* buf, char** argv);
int builtin_command(char** argv);
int changeDirectory(char* args[]);
int calcPipeNum(char* buf);
void evalOnePipe(char* cmdline);
void evalTwoPipe(char* cmdline);
int ARGC;


int changeDirectory(char* args[]) {
	if (args[1] == NULL) {
		int res = chdir(getenv("HOME"));
		return 1;
	}
	else {
		if (chdir(args[1]) == -1) {
			printf(" Enable to move directory : %s\n", args[1]);
			return -1;
		}
		return 0;
	}
}



int main()
{

	char cmdline[MAXLINE];

	while (1) {
		printf("MyShell > ");
		Fgets(cmdline, MAXLINE, stdin);
		if (feof(stdin))
			exit(0);
		eval(cmdline);
	}
}
/* $end shellmain */

/* $begin eval */
/* eval - Evaluate a command line */


void eval(char* cmdline)
{
	char* argv[MAXARGS]; /* Argument list execve() */
	char buf[MAXLINE];   /* Holds modified command line */
	int bg;              /* Should the job run in bg or fg? */
	pid_t pid;           /* Process id */

	char buf_copy[MAXLINE];
	strcpy(buf_copy, cmdline);

	

	strcpy(buf, cmdline);
	bg = parseline(buf, argv);
	if (argv[0] == NULL)
		return;   /* Ignore empty lines */
	if (!builtin_command(argv)) {

		// Not in bulletin, try to run execve
		if ((pid = Fork()) == 0) {   /* Child runs user job */

			//printf("Child forked\n");

			/*
			char* tmp=(char*)malloc(sizeof(char)*16);
			strcpy(tmp,"/bin/");
			strcat(tmp,argv[0]);

			//execve(argv[0],argv,environ);

			for(int i=0;i<10;i++){
				if(argv[i]!=NULL)
					printf("argv[%d] : %s\n",i,argv[i]);
			}
			printf("Res : %d\n\n",execve(tmp,argv,environ));
			if(execve(tmp,argv,environ)<0){
			*/


			//printf("Here!");
			int i,childStat;
			if(!strcmp(argv[0],"exit")){

				//printf("Here\n");
				kill(pid,SIGINT);


			}
			else{
				if (execvp(argv[0], argv) < 0) {
					printf("%s: Command not found.\n", argv[0]);
					exit(0);
				}
			}

		} // end of pid=Fork
	/* Parent waits for foreground job to terminate */
		if (!bg) {
			int status;
			if (waitpid(pid, &status, 0) < 0)
				unix_error("waitfg: waitpid error");
		}
		else
			printf("%d %s", pid, cmdline);
	}// end of bulletin

	return;
}

/* If first arg is a builtin command, run it and return true */
int builtin_command(char** argv)
{
	if (!strcmp(argv[0], "quit")) /* quit command */
		exit(0);
	else if (!strcmp(argv[0], "&"))    /* Ignore singleton & */
		return 1;
	else if (!strcmp(argv[0],"exit")){
		return 0;
	}
	else if (!strcmp(argv[0], "cd")) {
		changeDirectory(argv);
		//printf("res : %d\n",changeDirectory(argv));
		return 3;
	}
	return 0;                     /* Not a builtin command */
}
/* $end eval */

/* $begin parseline */
/* parseline - Parse the command line and build the argv array */
int parseline(char* buf, char** argv)
{
	char* delim;         /* Points to first space delimiter */
	int argc;            /* Number of args */
	int bg;              /* Background job? */

	buf[strlen(buf) - 1] = ' ';  /* Replace trailing '\n' with space */
	while (*buf && (*buf == ' ')) /* Ignore leading spaces */
		buf++;

	/* Build the argv list */
	argc = 0;
	while ((delim = strchr(buf, ' '))) {
		argv[argc++] = buf;
		*delim = '\0';
		buf = delim + 1;
		while (*buf && (*buf == ' ')) /* Ignore spaces */
			buf++;
	}
	argv[argc] = NULL;

	if (argc == 0)  /* Ignore blank line */
		return 1;

	/* Should the job run in the background? */
	if ((bg = (*argv[argc - 1] == '&')) != 0)
		argv[--argc] = NULL;

	ARGC = argc;
	return bg;
}
/* $end parseline */


